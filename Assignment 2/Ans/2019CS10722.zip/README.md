# COL226: ASSIGNMENT2 (Lexer and Parser)


  ### __How to run:__
1. Run the makefile by command "make"
2. SML files with the name "bool.lex.sml", "bool.yacc.sig", "bool.yacc.sml", "bool.yacc.desc" and executable
"a2" will be generated.
3. Now call the executable a2 with the name of file conataining formula (for example you want to do anaysis on
f.txt then write: ./a2 f.txt)
4. Output will be generated in the terminal.
5. If you want to check functions used and their types, just type "use loader.sml" in SML/NJ environment.
6. Furthermore if you wan to produce output in SML/NJ environment only then type (compile "f.txt") in sml.
7. Output will be generated in the SML environment. 
8. Run command make clean to delete all sml files and executable generated.
